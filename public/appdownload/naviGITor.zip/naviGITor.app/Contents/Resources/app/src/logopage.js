import React, {Component} from 'react';

export default class Logo extends Component {
  render() {
    return (
        <div id='logo-container'>
            <img className="landing-logo" src="./images/darknaviGitorLogo_1.png" />
        </div>
    )
  }
}
