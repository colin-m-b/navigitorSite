// Put xterm  into global to work around electron issues
// Currently unable to use 'import'
const Terminal = require('xterm');
