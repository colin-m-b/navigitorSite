import { expect } from 'chai';

describe('Mocha & Chai works', () => {
  it('Should pass', () => {
    expect(2).to.equal(2);
  });
});
